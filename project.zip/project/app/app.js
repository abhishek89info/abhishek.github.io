//Define an angular module for our app
var app = angular.module('myApp', ['ui.bootstrap']);

app.controller('autocompleteController', function($scope, $http) {
  getmyData(); 
  function getmyData(){  
  $http.get("myData.json").success(function(data){
        $scope.myData = data;
		
       });
  };
});
